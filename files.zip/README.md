# KitchenCraft PK — Website

A simple 3-file website: no build tools, no dependencies, just plain HTML/CSS/JS.
It's built to be hosted for free on **GitHub Pages**.

## Files
- `index.html` — all the page content (products, prices, contact info)
- `style.css` — all the styling/colors
- `script.js` — the small bit of code that makes the mobile menu button work

## To edit something later
Open `index.html` in GitHub's editor (pencil icon) and:
- **Change a price**: find the product's `<span class="price">Rs. 2,499</span>` line and edit the number.
- **Change a description**: edit the text inside `<p class="desc">...</p>` for that product.
- **Add a new product**: copy one whole `<article class="product-card">...</article>` block and paste it right after another one, then change its text.
- **Change contact info**: edit the `<ul class="contact-list">` section near the bottom.

No coding experience needed — you're just editing text between the `<tags>`, not the tags themselves.
